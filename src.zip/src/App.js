import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './pages/Login';
import RegisterPage from './pages/Register';
import Profile from './pages/Profile'; 
import Mention from './pages/Mention';
import './index.scss'; // 确保样式文件被引入

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/profile" element={<Profile />} /> 
        <Route path="/mention" element={<Mention />} /> 
        <Route path="/" element={<LoginPage />} /> {/* 设置默认路径为登录页面 */}
      </Routes>
    </Router>
  );
}

export default App;

