//路由配置

import React from 'react';
import { createBrowserRouter } from 'react-router-dom';
import LoginPage from '../pages/Login';
import RegisterPage from '../pages/Register'; // 确保你有注册页面组件
import Profile from '../pages/Profile'; // 导入 Profile 组件

const router = createBrowserRouter([
  {
    path: "/",
    element: <LoginPage />, // 将根路径直接指向 LoginPage
  },
  {
    path: "/register",
    element: <RegisterPage />,
  },
  {
    path: "//profile",
    element: <Profile />, // 将路径指向 Profile 页面
  },
  {
    path: "//mention",
    element: <Mention />, // 将路径指向 Profile 页面
  },
]);

export default router;
