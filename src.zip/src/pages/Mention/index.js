import React, { useState, useEffect } from 'react';
import { Button, Input, message, Pagination } from 'antd';
import axios from 'axios';
import './index.scss';
import Header from '../../components/Header/Header';

const PAGE_SIZE = 5;

const Mentioned = () => {
  const [posts, setPosts] = useState([]);
  const [newPost, setNewPost] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [userId, setUserId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const id = localStorage.getItem('userId');
    if (id) {
      setUserId(id);
    } else {
      console.error('用户未登录或未获取到用户 ID');
    }
  }, []);

  useEffect(() => {
    if (userId) {
      const fetchPosts = async () => {
        setLoading(true);
        try {
          const response = await axios.get('http://127.0.0.1:5000/comments');
          setPosts(response.data);
        } catch (error) {
          setError('获取帖子时出错');
        } finally {
          setLoading(false);
        }
      };

      fetchPosts();
    }
  }, [userId]);

  const handleAddPost = async () => {
    if (newPost.trim()) {
      setLoading(true);
      try {
        const postData = {
          text: newPost,
          user_id: userId,
        };
  
        const response = await axios.post('http://127.0.0.1:5000/comments', postData, {
          headers: {
            'Content-Type': 'application/json',
          },
        });
  
        const { comment_id } = response.data;
        console.log('New Comment ID:', comment_id);
      
        const postsResponse = await axios.get('http://127.0.0.1:5000/comments');
        setPosts(postsResponse.data);
  
        setNewPost('');
      } catch (error) {
        setError('添加帖子时出错');
      } finally {
        setLoading(false);
      }
    } else {
      message.error('没有内容要发布');
    }
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const startIndex = (currentPage - 1) * PAGE_SIZE;
  const currentPosts = posts.slice(startIndex, startIndex + PAGE_SIZE);

  return (
    <div className="mention-page">
      <Header />
      <div className="main-content">
        <div className="left-section">
          <div className="post-container">
            <div className="post-wrapper">
              <div className="add-post">
                <div className="textarea-container">
                  <textarea
                    value={newPost}
                    onChange={(e) => setNewPost(e.target.value)}
                    placeholder="写下你的帖子..."
                  />
                  <button className="post-button" onClick={handleAddPost}>发布</button>
                </div>
              </div>
              <div className="mention-content-wrapper">
                <div className="posts-list">
                  {loading ? <p>加载中...</p> : error ? <p>{error}</p> : (
                  currentPosts != undefined && currentPosts != null &&  currentPosts.length > 0 ? (
                      currentPosts.map((post) => (
                        <div key={post.id} className="post-item">
                          <div className="post-preview">
                            {post.image_url?.[0] && (
                              <img
                                src={post.image_url[0]}
                                alt="Post preview"
                                className="post-image"
                              />
                            )}
                            <div className="post-text-container">
                              <p className={`post-text ${post.isExpanded ? 'expanded' : 'collapsed'}`}>
                                {post.text}
                              </p>
                              {post.text != undefined && post.text != null && post.text.length > 100 && (
                                <button className="post-button2"
                                  onClick={() => setPosts(posts.map(p =>
                                    p.id === post.id ? { ...p, isExpanded: !p.isExpanded } : p
                                  ))}
                                >
                                  {post.isExpanded ? '收起' : '更多'}
                                </button>
                              )}
                            </div>
                          </div>
                          {/* 移除点赞、收藏、删除和回复相关功能 */}
                        </div>
                      ))
                    ) : (
                      <p>暂无帖子</p>
                    )
                  )}
                </div>
                <div className="pagination-container">
                  <Pagination
                    current={currentPage}
                    pageSize={PAGE_SIZE}
                    total={posts.length}
                    onChange={handlePageChange}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="right-section">
          <div className="tags">
            <h3>热门</h3>
            <div className="tag-list">
              {['高富帅', 'Yanami', '原神', '二次元', '动漫'].map((tag, index) => (
                <div key={index} className={`tag-item tag-item-${index + 1}`}>{tag}</div>
              ))}
            </div>
          </div>
          <div className="ranking">
            <h3>热门条目</h3>
            <p className="ranking-subtitle">本周排行</p>
            <ol>
              {[
                '败犬女主太多了',
                '八奈见杏菜',
                '志喜屋梦子',
                '马剃天爱星',
                '温水和彦',
                '周防有希',
                '放虎原云雀',
                '杖与剑的魔剑谭',
                '温水佳树',
                '白玉莉子'
              ].map((item, index) => (
                <li key={index} className="ranking-item">
                  <div className={`rank-number rank-${index + 1}`}>{index + 1}</div>
                  <div className="item-name">{item}</div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Mentioned;


